<template>
  <div class="error-layout text-center mt-4">
    <h1>{{ $t('error_alert_title') }}</h1>
    <p>{{ $t('error_alert_text') }}</p>
  </div>
</template>

<script>
export default {
  name: 'ErrorLayout'
}
</script>
